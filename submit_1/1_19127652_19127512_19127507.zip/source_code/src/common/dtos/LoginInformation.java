package common.dtos;

/**
 * common.dtos
 * Created by NhatLinh - 19127652
 * Date 4/8/2022 - 12:29 AM
 * Description: ...
 */
public record LoginInformation (String username, String password) {
}
