package common.gui.table.cells;

import administrator.gui.IComponent;

/**
 * administrator.gui
 * Created by NhatLinh - 19127652
 * Date 2/22/2022 - 1:22 PM
 * Description: ...
 */
public interface ICell extends IComponent {
}
