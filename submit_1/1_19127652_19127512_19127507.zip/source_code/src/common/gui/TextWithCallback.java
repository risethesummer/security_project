package common.gui;

/**
 * common.gui
 * Created by NhatLinh - 19127652
 * Date 5/5/2022 - 4:31 PM
 * Description: ...
 */
public record TextWithCallback(String text, Runnable callback) {
}
