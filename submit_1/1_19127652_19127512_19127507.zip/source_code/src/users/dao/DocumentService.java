package users.dao;

/**
 * users.dao
 * Created by NhatLinh - 19127652
 * Date 5/5/2022 - 5:56 PM
 * Description: ...
 */

import java.util.Date;
public record DocumentService (String serviceID, Date date, String technicianID, String result){
}
