package users.dao;

/**
 * users.dao
 * Created by NhatLinh - 19127652
 * Date 5/5/2022 - 2:29 PM
 * Description: ...
 */
public interface DBRecord {
}
