package users.dao;

/**
 * users.dao
 * Created by NhatLinh - 19127652
 * Date 5/5/2022 - 5:49 PM
 * Description: ...
 */
public record Facility (String id, String name, String address, String phone) implements DBRecord{
}
