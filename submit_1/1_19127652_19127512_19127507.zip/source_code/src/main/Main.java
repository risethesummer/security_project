package main;

import javax.swing.*;

/**
 * PACKAGE_NAME
 * Created by NhatLinh - 19127652
 * Date 2/16/2022 - 10:17 AM
 * Description: ...
 */
public class Main {

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(MainFrame::new);
    }
}
