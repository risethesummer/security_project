package administrator.dao.permissions;

/**
 * administrator.dao
 * Created by NhatLinh - 19127652
 * Date 2/22/2022 - 5:20 PM
 * Description: ...
 */
public enum PermissionType {
    INSERT, DELETE, UPDATE, SELECT
}
