package administrator.gui.privileges.userRole;

/**
 * administrator.gui.userOnDB.viewDB
 * Created by NhatLinh - 19127652
 * Date 3/14/2022 - 3:55 PM
 * Description: ...
 */
/*public class ShowTablePrivilegesPanel extends SearchingDBObjectPanel {

    public ShowTablePrivilegesPanel() {
        super();
        contentSection.setBorder(BorderFactory.createTitledBorder("Employee"));
    }
}*/
