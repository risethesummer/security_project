package administrator.dao;

/**
 * administrator.dao
 * Created by NhatLinh - 19127652
 * Date 2/22/2022 - 5:22 PM
 * Description: ...
 */
public enum DBObjectType {
    TABLE, STORED_PROCEDURE, VIEW, USER, ROLE, PROPERTY
}
