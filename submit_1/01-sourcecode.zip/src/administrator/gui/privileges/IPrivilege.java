package administrator.gui.privileges;

/**
 * administrator.gui.privileges
 * Created by NhatLinh - 19127652
 * Date 3/30/2022 - 11:28 PM
 * Description: ...
 */
public interface IPrivilege {
}
