package administrator.gui;

import javax.swing.*;
import java.awt.*;

/**
 * administrator.gui
 * Created by NhatLinh - 19127652
 * Date 3/31/2022 - 9:50 AM
 * Description: ...
 */
public interface IComponent {

    Component getComponent();
}
